﻿// File: Helpers/SessionHelper.cs
using Microsoft.AspNetCore.Http;
using System.Text.Json;
using training_project.Models;

namespace training_project.Helpers
{
    public static class SessionHelper
    {
        public static void SetCartItems(this ISession session, List<CartItemViewModel> cartItems)
        {
            session.SetString("cart", JsonSerializer.Serialize(cartItems));
        }

        public static List<CartItemViewModel> GetCartItems(this ISession session)
        {
            var cartJson = session.GetString("cart");
            return cartJson == null
                ? new List<CartItemViewModel>()
                : JsonSerializer.Deserialize<List<CartItemViewModel>>(cartJson)!;
        }
    }
}
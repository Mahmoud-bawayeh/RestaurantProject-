﻿using Microsoft.AspNetCore.Mvc;
using Microsoft.EntityFrameworkCore;
using System;
using System.IO;
using System.Linq;
using System.Text.Json;
using System.Threading.Tasks;
using training_project.Models;
using training_project.Helpers;

namespace training_project.Controllers
{
    public class ProductsController : Controller
    {
        private readonly ShopmvcEntityFContext _context;

        public ProductsController(ShopmvcEntityFContext context)
        {
            _context = context;
        }

        // GET: Products/AddProduct
        public IActionResult AddProduct()
        {
            var viewModel = new ProductFormViewModel();
            return View(viewModel);
        }

        [HttpPost]
        [ValidateAntiForgeryToken]
        public async Task<IActionResult> AddProduct(ProductFormViewModel model)
        {
            if (ModelState.IsValid)
            {
                string? imagePath = null;

                if (model.ImageFile != null && model.ImageFile.Length > 0)
                {
                    var uploadsFolder = Path.Combine(Directory.GetCurrentDirectory(), "wwwroot", "images");
                    var uniqueFileName = Guid.NewGuid().ToString() + "_" + model.ImageFile.FileName;
                    var filePath = Path.Combine(uploadsFolder, uniqueFileName);

                    using (var fileStream = new FileStream(filePath, FileMode.Create))
                    {
                        await model.ImageFile.CopyToAsync(fileStream);
                    }

                    imagePath = "/images/" + uniqueFileName;
                }

                var product = new Product
                {
                    ProductName = model.ProductName,
                    UnitPrice = model.UnitPrice,
                    AmountInStock = model.AmountInStock,
                    Description = model.Description,
                    ImagePath = imagePath,
                    ProductType = model.ProductType,
                    Active = true
                };

                _context.Products.Add(product);
                await _context.SaveChangesAsync();

                if (model.ProductType == "Book")
                {
                    var book = new Book
                    {
                        Author = model.Author,
                        Isbn = model.Isbn,
                        ProductId = product.Id
                    };
                    _context.Books.Add(book);
                }
                else if (model.ProductType == "Cup")
                {
                    var cup = new Cup
                    {
                        Color = model.Color,
                        Size = model.Size,
                        Manufacturer = model.Manufacturer,
                        ProductId = product.Id
                    };
                    _context.Cups.Add(cup);
                }

                await _context.SaveChangesAsync();

                return RedirectToAction("Index");
            }

            return View(model);
        }
        [HttpPost]
        [ValidateAntiForgeryToken]
        public IActionResult Checkout()
        {
            var cart = HttpContext.Session.GetCartItems();

            if (cart.Count == 0)
            {
                TempData["ErrorMessage"] = "Your cart is empty.";
                return RedirectToAction("Cart");
            }

            // 🔐 Check if user is logged in
            var userId = HttpContext.Session.GetInt32("UserId");

            if (!userId.HasValue)
            {
                TempData["ErrorMessage"] = "You must be logged in to checkout.";
                return RedirectToAction("Login", "Account");
            }


            var userName = HttpContext.Session.GetString("UserName") ?? "Unknown User";

            // Create order
            var order = new Order
            {
                UserId = userId.Value, // Store as string or update model to use int
                TotalAmount = cart.Sum(i => i.Total),
                Items = cart.Select(i => new OrderItem
                {
                    ProductId = i.ProductId,
                    ProductName = i.ProductName,
                    UnitPrice = i.UnitPrice,
                    Quantity = i.Quantity
                }).ToList()
            };

            try
            {
                // Reduce stock for each item
                foreach (var item in cart)
                {
                    var product = _context.Products.FirstOrDefault(p => p.Id == item.ProductId);

                    if (product == null)
                    {
                        TempData["ErrorMessage"] = $"Product '{item.ProductName}' not found.";
                        return RedirectToAction("Cart");
                    }

                    if (product.AmountInStock < item.Quantity)
                    {
                        TempData["ErrorMessage"] = $"Not enough stock for '{product.ProductName}'. Only {product.AmountInStock} left.";
                        return RedirectToAction("Cart");
                    }

                    product.AmountInStock -= item.Quantity;
                    _context.Products.Update(product);
                }

                // Save order
                _context.Orders.Add(order);
                _context.SaveChanges(); // Saves both order and updated product stock

                // Clear cart
                HttpContext.Session.SetCartItems(new List<CartItemViewModel>());

                return RedirectToAction("OrderConfirmation", new { id = order.Id });
            }
            catch (Exception ex)
            {
                var innerException = ex.InnerException?.Message ?? ex.Message;
                TempData["ErrorMessage"] = $"Error saving order: {innerException}";
                return RedirectToAction("Cart");
            }
        }
        public IActionResult OrderConfirmation(int id)
        {
            var order = _context.Orders
                .Include(o => o.Items)
                .FirstOrDefault(o => o.Id == id);

            if (order == null)
            {
                return NotFound();
            }

            return View(order);
        }
        // GET: Products/Index
        public IActionResult Index(string searchString, string productType, decimal? minPrice, decimal? maxPrice, int page = 1)
        {
            int pageSize = 10;

            var query = _context.Products.AsQueryable();

            // Apply search filter
            if (!string.IsNullOrEmpty(searchString))
            {
                query = query.Where(p => p.ProductName.Contains(searchString));
                ViewData["CurrentFilter"] = searchString;
            }

            // Apply type filter
            if (!string.IsNullOrEmpty(productType))
            {
                query = query.Where(p => p.ProductType == productType);
                ViewData["CurrentType"] = productType;
            }

            // Apply price range filter
            if (minPrice.HasValue)
            {
                query = query.Where(p => p.UnitPrice >= minPrice.Value);
                ViewData["MinPrice"] = minPrice.Value;
            }

            if (maxPrice.HasValue)
            {
                query = query.Where(p => p.UnitPrice <= maxPrice.Value);
                ViewData["MaxPrice"] = maxPrice.Value;
            }

            var totalItems = query.Count();

            var paginatedProducts = query
                .Skip((page - 1) * pageSize)
                .Take(pageSize)
                .ToList();

            ViewBag.CurrentPage = page;
            ViewBag.TotalPages = (int)Math.Ceiling(totalItems / (double)pageSize);
            ViewBag.TotalItems = totalItems;

            return View(paginatedProducts);
        }

        // GET: Products/Details/5
        public IActionResult Details(int id)
        {
            var product = _context.Products
                .FirstOrDefault(p => p.Id == id);

            if (product == null)
            {
                return NotFound();
            }

            return View(product);
        }

        // GET: Products/Edit/5
        // GET: Products/Edit/5
        public IActionResult Edit(int id)
        {
            var product = _context.Products
                .FirstOrDefault(p => p.Id == id);

            if (product == null)
            {
                return NotFound();
            }

            return View(product);
        }

        // POST: Products/Edit/5
        [HttpPost]
        [ValidateAntiForgeryToken]
        public async Task<IActionResult> Edit(int id, [Bind("Id,ProductName,UnitPrice,AmountInStock,Description,ImagePath,ProductType")] Product product)
        {
            if (id != product.Id)
            {
                return NotFound();
            }

            if (ModelState.IsValid)
            {
                try
                {
                    // Attach existing entity to context to update it
                    var existingProduct = await _context.Products.FindAsync(id);
                    if (existingProduct == null)
                    {
                        return NotFound();
                    }

                    // Update fields
                    existingProduct.ProductName = product.ProductName;
                    existingProduct.UnitPrice = product.UnitPrice;
                    existingProduct.AmountInStock = product.AmountInStock;
                    existingProduct.Description = product.Description;
                    existingProduct.ImagePath = product.ImagePath;       // Include read-only field
                    existingProduct.ProductType = product.ProductType;   // Include read-only field

                    _context.Update(existingProduct);
                    await _context.SaveChangesAsync();

                    // Redirect after successful save
                    return RedirectToAction(nameof(Index));
                }
                catch (Exception ex)
                {
                    // Log exception if needed
                    ModelState.AddModelError("", "Unable to save changes. Try again.");
                }
            }

            // If validation fails, redisplay form
            return View(product);
        }


        // GET: Products/Delete/5
        public IActionResult Delete(int id)
        {
            var product = _context.Products
                .FirstOrDefault(p => p.Id == id);

            if (product == null)
            {
                return NotFound();
            }

            return View(product);
        }

        // POST: Products/Delete/5
        [HttpPost, ActionName("Delete")]
        [ValidateAntiForgeryToken]
        public async Task<IActionResult> DeleteConfirmed(int id)
        {
            var product = await _context.Products.FindAsync(id);

            if (product == null)
            {
                return NotFound();
            }

            if (product.ProductType == "Book")
            {
                var book = _context.Books.FirstOrDefault(b => b.ProductId == id);
                if (book != null)
                {
                    _context.Books.Remove(book);
                }
            }
            else if (product.ProductType == "Cup")
            {
                var cup = _context.Cups.FirstOrDefault(c => c.ProductId == id);
                if (cup != null)
                {
                    _context.Cups.Remove(cup);
                }
            }

            _context.Products.Remove(product);
            await _context.SaveChangesAsync();

            return RedirectToAction(nameof(Index));
        }

        // POST: Products/AddToCart/5
        [HttpPost]
        public IActionResult AddToCart(int id, int quantity = 1)
        {
            var product = _context.Products.FirstOrDefault(p => p.Id == id);

            if (product == null)
            {
                return NotFound();
            }

            var cart = HttpContext.Session.GetCartItems();

            var existingItem = cart.FirstOrDefault(c => c.ProductId == id);

            if (existingItem != null)
            {
                existingItem.Quantity += quantity;
            }
            else
            {
                cart.Add(new CartItemViewModel
                {
                    ProductId = product.Id,
                    ProductName = product.ProductName,
                    UnitPrice = product.UnitPrice,
                    ImagePath = product.ImagePath,
                    Quantity = quantity,
                    InStock = product.AmountInStock
                });
            }

            HttpContext.Session.SetCartItems(cart);

            TempData["SuccessMessage"] = "Product added to cart!";
            return RedirectToAction("Index");
        }

        // GET: Products/Cart
        public IActionResult Cart()
        {
            var cart = HttpContext.Session.GetCartItems();
            return View(cart);
        }

        // POST: Products/RemoveFromCart/5
        public IActionResult RemoveFromCart(int id)
        {
            var cart = HttpContext.Session.GetCartItems();
            var item = cart.FirstOrDefault(c => c.ProductId == id);

            if (item != null)
            {
                cart.Remove(item);
                HttpContext.Session.SetCartItems(cart);
            }

            return RedirectToAction("Cart");
        }
    }
}
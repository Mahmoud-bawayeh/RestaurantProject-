﻿using Microsoft.AspNetCore.Mvc;
using training_project.Models;
using System.Linq;
using System.Threading.Tasks;

namespace training_project.Controllers
{
    public class AccountController : Controller
    {
        private readonly ShopmvcEntityFContext _context;

        public AccountController(ShopmvcEntityFContext context)
        {
            _context = context;
        }

        // GET: /Account/Login
        [HttpGet]
        public IActionResult Login()
        {
            return View();
        }

        // POST: /Account/Login
        // POST: /Account/Login
        [HttpPost]
        [ValidateAntiForgeryToken]
        public IActionResult Login(LoginViewModel model)
        {
            if (ModelState.IsValid)
            {
                var user = _context.Users.FirstOrDefault(u => u.UserName == model.UserName);

                if (user == null)
                {
                    // User not found
                    ModelState.AddModelError("", "User not found. Please register.");
                    return View(model);
                }

                if (user.Password != model.Password)
                {
                    // Wrong password
                    ModelState.AddModelError("", "Invalid password.");
                    return View(model);
                }

                // Success: Log the user in
                HttpContext.Session.SetInt32("UserId", user.Id);
                HttpContext.Session.SetString("UserName", user.UserName);

                TempData["SuccessMessage"] = $"Welcome back, {user.UserName}!";
                return RedirectToAction("Index", "Products");
            }

            return View(model);
        }

        // GET: /Account/Register
        [HttpGet]
        public IActionResult Register()
        {
            return View();
        }

        // POST: /Account/Register
        [HttpPost]
        [ValidateAntiForgeryToken]
        public async Task<IActionResult> Register(RegisterViewModel model)
        {
            if (ModelState.IsValid)
            {
                var existingUser = _context.Users.FirstOrDefault(u => u.UserName == model.UserName);

                if (existingUser != null)
                {
                    ModelState.AddModelError("UserName", "Username already taken.");
                    return View(model);
                }

                var user = new User
                {
                    UserName = model.UserName,
                    Password = model.Password
                };

                _context.Users.Add(user);
                await _context.SaveChangesAsync();

                TempData["SuccessMessage"] = "Registration successful! Please login.";
                return RedirectToAction("Login");
            }

            return View(model);
        }

        // POST: /Account/Logout
        [HttpPost]
        public IActionResult Logout()
        {
            // Clear session
            HttpContext.Session.Clear();

            // Set success message
            TempData["SuccessMessage"] = "You have been logged out.";

            // Redirect to login page
            return RedirectToAction("Login");
        }
    }
}
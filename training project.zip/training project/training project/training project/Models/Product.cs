﻿using System;
using System.Collections.Generic;

namespace training_project.Models;

public partial class Product
{
    public int Id { get; set; }

    public string ProductName { get; set; } = null!;

    public string? ImagePath { get; set; }

    public decimal UnitPrice { get; set; }

    public string? ProductType { get; set; }

    public int AmountInStock { get; set; }

    public string? Description { get; set; }

    public bool Active { get; set; }

    public virtual ICollection<Book> Books { get; set; } = new List<Book>();

    public virtual ICollection<Cart> Carts { get; set; } = new List<Cart>();

    public virtual ICollection<Cup> Cups { get; set; } = new List<Cup>();
}

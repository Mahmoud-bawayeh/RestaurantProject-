﻿namespace training_project.Models
{
    public class CartItemViewModel
    {
        public int ProductId { get; set; }
        public string ProductName { get; set; } = string.Empty;
        public decimal UnitPrice { get; set; }
        public string? ImagePath { get; set; }
        public int Quantity { get; set; }
        public int InStock { get; set; } // New field
        public decimal Total => UnitPrice * Quantity;
    }
}
﻿using System;
using System.Collections.Generic;

namespace training_project.Models;

public partial class Cup
{
    public int Id { get; set; }

    public string? Color { get; set; }

    public string? Size { get; set; }

    public string? Manufacturer { get; set; }

    public int ProductId { get; set; }

    public virtual Product Product { get; set; } = null!;
}

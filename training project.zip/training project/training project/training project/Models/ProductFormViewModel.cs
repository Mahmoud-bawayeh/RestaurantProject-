﻿using Microsoft.AspNetCore.Mvc.Rendering;
using System.ComponentModel.DataAnnotations;

namespace training_project.Models
{
    public class ProductFormViewModel
    {
        // Common Product Fields
        [Required]
        public string ProductName { get; set; }

        [Required]
        public decimal UnitPrice { get; set; }

        [Required]
        public int AmountInStock { get; set; }

        public string? Description { get; set; }

        [Required]
        public IFormFile ImageFile { get; set; }

        [Required]
        public string ProductType { get; set; } // "Sandwich" or "Meal"

        // Sandwich-specific fields (reusing Book fields)
        public string? Author { get; set; }
        public string? Isbn { get; set; }

        // Meal-specific fields (reusing Cup fields)
        public string? Color { get; set; }
        public string? Size { get; set; }
        public string? Manufacturer { get; set; }

        // Dropdown for selecting type
        public IEnumerable<SelectListItem> ProductTypes => new List<SelectListItem>
        {
            new SelectListItem { Value = "Sandwich", Text = "Sandwich" },
            new SelectListItem { Value = "Meal", Text = "Meal" }
        };
    }
}

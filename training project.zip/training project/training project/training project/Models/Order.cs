﻿using System;
using System.Collections.Generic;

namespace training_project.Models
{
    public class Order
    {
        public int Id { get; set; }
        public int UserId { get; set; } 
        public DateTime OrderDate { get; set; } = DateTime.Now;
        public decimal TotalAmount { get; set; }

        // Navigation property for order items
        public ICollection<OrderItem> Items { get; set; } = new List<OrderItem>();
    }
}